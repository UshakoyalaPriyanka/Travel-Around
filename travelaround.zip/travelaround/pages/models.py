from django.db import models

class Place(models.Model): 
	title = models.CharField(max_length=255) 	
	description = models.CharField(max_length=10000) 
	image = models.FileField(upload_to="uploads/places/")
	category_id = models.BigIntegerField(default=0)
	city = models.CharField(max_length=100)
	state_id = models.BigIntegerField(default=0)
	country = models.CharField(max_length=100)
	is_popular = models.BooleanField(default=0)
	created_at = models.DateField()
class Meta: 
	db_table = 'Places'

class State(models.Model): 
	name = models.CharField(max_length=255)
	country = models.CharField(max_length=100)
	created_at = models.DateField()
class Meta: 
	db_table = 'States'

class Category(models.Model): 
	name = models.CharField(max_length=255)
	status = models.BooleanField(default=0)
	created_at = models.DateField()
class Meta: 
	db_table = 'Categories'
