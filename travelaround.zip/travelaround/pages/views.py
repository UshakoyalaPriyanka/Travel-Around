from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Place

def index(request):
  places = Place.objects.all()
  destinations = Place.objects.filter(category_id=1)
  hillstations = Place.objects.filter(category_id=2)
  pilgrims = Place.objects.filter(category_id=3)
  context = {'places':places, 'destinations':destinations, 'hillstations':hillstations, 'pilgrims':pilgrims}
  template = loader.get_template('home.html')
  return HttpResponse(template.render(context))

def blog(request):
  template = loader.get_template('blog.html')
  return HttpResponse(template.render())

def contact(request):
  template = loader.get_template('contact.html')
  return HttpResponse(template.render())

def destinations(request):
  destinations = Place.objects.filter(category_id=1)
  context = {'destinations':destinations}
  template = loader.get_template('destinations.html')
  return HttpResponse(template.render(context))

def popularDestinations(request):
  destinations = Place.objects.filter(is_popular=1)
  context = {'destinations':destinations}
  template = loader.get_template('popular_destinations.html')
  return HttpResponse(template.render(context))

def hillstations(request):
  hillstations = Place.objects.filter(category_id=2)
  context = {'hillstations':hillstations}
  template = loader.get_template('hillstations.html')
  return HttpResponse(template.render(context))

def pilgrims(request):
  pilgrims = Place.objects.filter(category_id=3)
  context = {'pilgrims':pilgrims}
  template = loader.get_template('pilgrims.html')
  return HttpResponse(template.render(context))

def placeDetails(request, id=None):
  place = Place.objects.get(pk=id)
  context = {'place':place}
  template = loader.get_template('place_details.html')
  return HttpResponse(template.render(context))