from django.contrib import admin
from .models import Place
from .models import State
from .models import Category

admin.site.register(Place)
admin.site.register(State)
admin.site.register(Category)
